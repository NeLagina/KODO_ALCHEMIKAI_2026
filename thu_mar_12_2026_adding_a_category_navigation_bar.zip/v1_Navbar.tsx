import { useEffect, useRef, useState } from "react";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (open) closeRef.current?.focus();
  }, [open]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    if (open) window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <>
      <button aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(v => !v)}>
        ☰
      </button>

      {open && <div className="backdrop" onClick={() => setOpen(false)} />}

      <nav id="mobile-nav" className={`nav ${open ? "is-open" : ""}`} aria-hidden={!open}>
        <button ref={closeRef} className="nav-close" aria-label="Close menu" onClick={() => setOpen(false)}>
          ×
        </button>

        {/* links... */}
      </nav>
    </>
  );
}